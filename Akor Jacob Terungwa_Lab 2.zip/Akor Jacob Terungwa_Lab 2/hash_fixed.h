#ifndef __HASH_FIXED__
#define __HASH_FIXED__

#include <stdbool.h> // For boolean types

#define KEY_STRING_MAX 255
#define MAP_MAX 128

// PairValue structure with collision resolution via linked list
typedef struct PairValue {
    char KeyName[KEY_STRING_MAX]; // Key with max length
    int ValueCount;              // Associated value
    struct PairValue* Next;      // Pointer for chaining
} PairValue;

// HashMap structure
typedef struct {
    PairValue* data[MAP_MAX]; // Array of pointers for key-value pairs
} HashMap;

// Function prototypes
HashMap* HashInit();
//I added the const bellow to parameters like key to enforce immutability
bool HashAdd(HashMap *map, const PairValue *value);
bool HashDelete(HashMap *map, const char* key);
PairValue* HashFind(const HashMap *map, const char* key);
//Explanation: why it works, because it prevents unintended modification of data and ensures functions are used as intended.
// Also prevents overwriting data on hash collisions by linking multiple entries at the same hash index.
void HashDump(const HashMap *map);

#endif // __HASH_FIXED__
