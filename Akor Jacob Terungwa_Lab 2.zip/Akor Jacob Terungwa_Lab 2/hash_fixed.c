unsigned HashIndex(const char* key) {
    unsigned sum = 0;
    for (const char* c = key; *c != '\0'; c++) {  // Correct loop condition
                                        //Explanation: The loop now correctly iterates until the end of the string (*c != '\0').
        sum += *c;
    }
    return sum;
}

HashMap* HashInit() {
    HashMap* map = malloc(sizeof(HashMap));
    if (map == NULL) {
        fprintf(stderr, "Memory allocation failed\n");
        exit(EXIT_FAILURE);
    }
    return map;
}   //Explanation: I have added error checking for malloc to handle memory allocation failures carefully

void HashAdd(HashMap *map, PairValue *value) {
    unsigned idx = HashIndex(value->KeyName);
    
    if (map->data[idx]) 
        value->Next = map->data[idx];  // This is the Correct pointer assignment for the function
    map->data[idx] = value;	
}   // Explanation: I fixed the pointer assignment to maintain the linked list correctly.

PairValue* HashFind(HashMap *map, const char* key) {
    unsigned idx = HashIndex(key);
    
    for( PairValue* val = map->data[idx]; val != NULL; val = val->Next ) {
        if (strcmp(val->KeyName, key) == 0)  // This ensures a correct string comparison
        //Explanation: I replaced strcpy with strcmp for proper string comparison.
            return val;
    }
    
    return NULL; 
}


void HashDelete(HashMap *map, const char* key) {
    unsigned idx = HashIndex(key);
    
    for( PairValue* val = map->data[idx], *prev = NULL; val != NULL; prev = val, val = val->Next ) {
        if (strcmp(val->KeyName, key) == 0) {  // Correct string comparison
            if (prev)
                prev->Next = val->Next;
            else
                map->data[idx] = val->Next;
            free(val);  // Free the deleted node
            break;
        }
    }
}   // Explanation: I replaced strcpy with strcmp and added free(val) to avoid memory leaks.

void HashDump(HashMap *map) {
    for( unsigned i = 0; i < MAP_MAX; i++ ) {
        for( PairValue* val = map->data[i]; val != NULL; val = val->Next ) {
            printf("%s\n", val->KeyName);  // Safe use of printf
        }
    }
}   //Explanation: I added a format string ("%s\n") to printf so as to prevent format string vulnerabilities.