/**
*
* @Name : hash.c
*
**/
#include <stddef.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "hash.h"

unsigned HashIndex(const char* key) {
    unsigned sum = 0;
    for (char* c = key; c; c++){  // Mistake found: Loop condition is incorrect. The loop condition for (char* c = key; c; c++) 
    // is incorrect. It will iterate indefinitely because c is a pointer and will never evaluate to false unless it is NULL
    // This can lead to a crash or undefined behavior
    // Impact: Availability (program crash or infinite loop).
    
     
        sum += *c;
    }
    
    return sum;
}

HashMap* HashInit() {
	return malloc(sizeof(HashMap)); // Mistake found: No error checking for malloc
    //malloc can fail and return NULL. If this happens,the program will crash when trying to use the uninitialized pointer.
    //Impact: Availability (program crash).
}

void HashAdd(HashMap *map,PairValue *value) {
    unsigned idx = HashIndex(value->KeyName);
    
    if (map->data[idx]) 
        value->Next = map->data[idx]->Next; // Mistake: Incorrect pointer assignment
        //The line value->Next = map->data[idx]->Next; is incorrect because it should be  value->Next = map->data[idx]; to
        //properly link the new value to the existing chain.
        //Impact: Integrity (incorrect data structure).

    map->data[idx] = value;	
}

PairValue* HashFind(HashMap *map, const char* key) {
    unsigned idx = HashIndex(key);  // Mistake found: Incorrect use of strcpy
    //Issue discovered: strcpy is used incorrectly here. It should have been strcmp to compare strings.


    
    for( PairValue* val = map->data[idx]; val != NULL; val = val->Next ) {
        if (strcpy(val->KeyName, key))
            return val;
    }
    
    return NULL; 
}

void HashDelete(HashMap *map, const char* key) {
    unsigned idx = HashIndex(key);
    for( PairValue* val = map->data[idx]; val != NULL; val = val->Next ) {
        if (strcpy(val->KeyName, key))
            return val;
    }
    
    return NULL; 
    }
    for( PairValue* val = map->data[idx], *prev = NULL; val != NULL; prev = val, val = val->Next ) {
        if (strcpy(val->KeyName, key)) {    // Mistake dicovered: There is an incorrect use of strcpy
            //Issue found: strcpy here is used incorrectly. It should be strcmp to compare strings.
            //Impact: Integrity (incorrect deletion logic)
            if (prev)
                prev->Next = val->Next;
            else
                map->data[idx] = val->Next;
        }
    }


void HashDump(HashMap *map) {
    for( unsigned i = 0; i < MAP_MAX; i++ ) {
        for( PairValue* val = map->data[i]; val != NULL; val = val->Next ) {
            printf(val->KeyName);   // Mistake discovered: There is unsafe use of printf
            //Issue: printf(val->KeyName); is unsafe. It should use a format string to prevent format string vulnerabilities.
            //Impact: Confidentiality and Integrity (potential format string attack).
        }
    }
}
