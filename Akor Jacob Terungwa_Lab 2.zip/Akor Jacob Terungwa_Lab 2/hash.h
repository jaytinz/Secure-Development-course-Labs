/**
*
* @Name : hash.h
*
**/
#ifndef __HASH__
#define __HASH__

    typedef struct {
        #define KEY_STRING_MAX 255
		char KeyName[KEY_STRING_MAX];//mistake discovered: There is a fixed-size array for key names
        // Issue found: The KeyName field is a fixed-size array of 255 characters.
        //While this prevents buffer overflows in some cases, it doesn't enforce input validation in the implementation.
        //If the input key exceeds 255 characters, it could lead to truncation or undefined behavior.
        //Category: Integrity (data truncation or corruption).
		int  ValueCount;
        struct PairValue* Next;
	} PairValue;

	typedef struct {
        #define MAP_MAX 128
		PairValue* data[MAP_MAX];//Mistake: The MAP_MAX constant defines the size of the hash table as 128. 
        // Issue discovered: This is a fixed size may not be sufficient for large datasets,leading to hash collisions and performance degradation.
        //Impact on Security: Availability (performance issues due to collisions).
	} HashMap;

    HashMap* HashInit(); //Lack of const in Function Parameters
    //Issue discovered: Functions like HashFind and HashDelete do not modify the map or the key.  Without const, these parameters could be unintentionally modified, risking data corruption.
    //Impact on Security:Integrity: Leads to unintended data modifications.
    void HashAdd(HashMap *map, PairValue *value);
    void HashDelete(HashMap *map, const char* key);
    PairValue* HashFind(HashMap *map, const char* key);
    void HashDump(HashMap *map);
#endif